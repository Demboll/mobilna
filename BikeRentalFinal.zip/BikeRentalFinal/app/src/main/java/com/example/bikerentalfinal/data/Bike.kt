package com.example.bikesrentalapp.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bike_table")
data class Bike(
    @PrimaryKey(autoGenerate = true) val id: Int?,
    @ColumnInfo(name = "brand") val brand: String?,
    @ColumnInfo(name = "model") val model: String?,
    @ColumnInfo(name = "bike_id") val bikeId: Int?,
    @ColumnInfo(name = "image_url") val imageUrl: String? // New field for image URL
)
