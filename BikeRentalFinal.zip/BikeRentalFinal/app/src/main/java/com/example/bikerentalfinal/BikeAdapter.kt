package com.example.bikerentalfinal

class BikeAdapter {
}