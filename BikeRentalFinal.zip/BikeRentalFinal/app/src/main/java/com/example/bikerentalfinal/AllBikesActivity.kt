package com.example.bikerentalfinal

class AllBikesActivity {
}